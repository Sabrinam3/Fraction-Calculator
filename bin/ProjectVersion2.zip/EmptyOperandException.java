import javax.swing.JOptionPane;

public class EmptyOperandException extends Exception
{
	public EmptyOperandException(String source) 
	{
		super();
		if(source.equals("numerator"))
		{
			JOptionPane.showMessageDialog(null, "Numerator field cannot be empty!","Error", JOptionPane.ERROR_MESSAGE);
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Denominator field cannot be empty!","Error", JOptionPane.ERROR_MESSAGE);
		}
	}//end constructor
}
//end class