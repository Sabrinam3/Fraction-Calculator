import javax.swing.JOptionPane;
public class LongOperandException extends Exception
{
	public LongOperandException()
	{
		JOptionPane.showMessageDialog(null, "Warning: operand entered exceeds int capacity", "Error", JOptionPane.ERROR_MESSAGE);
	}
}
//end class