import javax.swing.JOptionPane;
public class DenominatorOfZeroException extends Exception
{
	public DenominatorOfZeroException()
	{
		JOptionPane.showMessageDialog(null, "Denominator cannot be zero!", "Error", JOptionPane.ERROR_MESSAGE);
	}
}
//end class